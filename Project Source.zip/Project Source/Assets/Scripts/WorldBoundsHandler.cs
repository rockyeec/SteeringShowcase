using UnityEngine;

public class WorldBoundsHandler : MonoBehaviour
{
    readonly float minX = 0.0f;
    readonly float minZ = 0.0f;
    readonly float maxX = 100.0f;
    readonly float maxZ = 100.0f;

    Vector3 Position
    {
        get => transform.position;
        set => transform.position = value;
    }

    private void LateUpdate()
    {
        bool isDirty = false;
        if (Position.x > maxX)
        {
            isDirty = true;
            Position = Position.With(x: Position.x - maxX + minX); 
        }
        if (Position.z > maxZ)
        {
            isDirty = true;
            Position = Position.With(z: Position.z - maxZ + minZ);
        }
        if (Position.x < minX)
        {
            isDirty = true;
            Position = Position.With(x: Position.x - minX + maxX);
        }
        if (Position.z < minZ) 
        {
            isDirty = true;
            Position = Position.With(z: Position.z - minZ + maxZ);
        }

        if (isDirty)
        {
            float rayLength = 69.0f;
            if (Physics.Raycast(
            Position + 0.5f * rayLength * Vector3.up,
            Vector3.down,
            out RaycastHit hit,
            rayLength,
            ProjectConstants.groundLayer))
            {
                Position = hit.point;
            }
        }
    }
}
