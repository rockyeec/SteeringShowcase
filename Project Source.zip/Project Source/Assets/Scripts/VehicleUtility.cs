using UnityEngine;

public interface IVehicle
{ 
    Vector3 Target { get; }
    float Mass { get; }
    float MaxForce { get; }
    float MaxSpeed { get; }
    float SpeedFactor { get; }
    Vector3 Position { get; set; }
    Vector3 Velocity { get; set; }
    Quaternion Rotation { get; set; }
}

public static class VehicleUtility
{
    static int GroundLayer => ProjectConstants.groundLayer;
    static RaycastHit hit;
    public static void UpdateFromDesiredVelocity(IVehicle vehicle, Vector3 desiredVelocity, in float deltaTime, float rayLength = 2.0f)
    {
        float maxForce = Mathf.Max(vehicle.MaxForce, 0.0f);
        Vector3 steering = desiredVelocity - vehicle.Velocity;
        Vector3 steeringForce = Vector3.ClampMagnitude(steering, maxForce);
        UpdateFromSteeringForce(vehicle, steeringForce, deltaTime, rayLength);    
    }
    public static void UpdateFromSteeringForce(IVehicle vehicle, Vector3 steeringForce, in float deltaTime, float rayLength = 2.0f)
    {
        float mass = Mathf.Max(vehicle.Mass, 1e-2f);
        float maxSpeed = Mathf.Max(vehicle.MaxSpeed, 0.0f);

        Vector3 acceleration = steeringForce / mass;
        vehicle.Velocity = Vector3.ClampMagnitude(vehicle.Velocity + acceleration, maxSpeed);
        vehicle.Position += vehicle.Velocity * deltaTime;

        Vector3 pitchlessVelocity = vehicle.Velocity.With(y: 0.0f);
        if (pitchlessVelocity != Vector3.zero)
            vehicle.Rotation = Quaternion.LookRotation(pitchlessVelocity);

        vehicle.Position = GetGroundPoint(vehicle.Position, rayLength);
    }
    public static Vector3 GetGroundPoint(Vector3 input, float rayLength = 2.0f)
    {
        if (Physics.Raycast(
            input + 0.5f * rayLength * Vector3.up,
            Vector3.down,
            out hit,
            rayLength,
            GroundLayer))
        {
            return hit.point;
        }
        return input;
    }
}
