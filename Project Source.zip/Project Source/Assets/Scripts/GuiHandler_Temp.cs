using rockUtil;
using UnityEngine;
using System.Linq;

// Messy GUI class will change to proper UI soon
public class GuiHandler_Temp : MonoBehaviour
{
    [SerializeField] Texture arrowTexture = null;
    [SerializeField] SelectedUnits selectedUnits = null;
    [SerializeField] UnitOrderIssuer orderIssuer = null;

    SteerData[] states;
    class SteerData
    {
        public SteerData(System.Type type)
        {
            Type = type;
        }
        public Rect Rect { get; set; }
        public System.Type Type { get; }
    }


    Rect arrowRect = new Rect(0.0f, 0.0f, 69.0f, 69.0f);
    float arrowHeight;
    float BounceAnimation => -Mathf.Sin(1.0f - Mathf.Sin(1 + Mathf.Sin(Time.time * 6.9f)));

    private void Awake()
    {
        InitButtonRects();
    }

    private void OnGUI()
    {
        #region GUI background panel
        GUI.Box(ProjectConstants.bottomPanel, string.Empty);
        #endregion

        #region Tutorial Message
        {
            Rect tutorialRect = new Rect(10.0f, 10.0f, 420.0f, 150.0f);
            GUI.Box(tutorialRect, 
            "CONTROLS\n\nLeft Click to select\nDrag Left Click to box select multiple units\nRight Click to set target\nDrag Right Click to set group formation\nLeft click ground to deselect\nScroll Mouse to Change Camera Angle and Height\nMouse Edge Pan Camera");
        }
        #endregion

        float bounceAnimation = BounceAnimation;

        #region Per Unit Pointer Arrows
        selectedUnits.ForEach(item =>
        {
            if ((item.Position - item.Target).sqrMagnitude < 1e-1f)
                return;

            Vector2 tar = MouseGetter.Camera.WorldToScreenPoint(item.Target);
            float width = 25f;
            GUI.DrawTexture(new Rect(
                tar.x - width / 2.0f, 
                Screen.height - (tar.y + width / 2.0f) + bounceAnimation * 12f, 
                width,
                width),
                arrowTexture);
        });

        if (Input.GetMouseButton(1))
        {
            int i = 0;
            float total = selectedUnits.Count;
            if ((int)total > 0 && orderIssuer.IsMouseHeldLongEnough)
            {
                selectedUnits.ForEach(item =>
                {
                    Vector2 tar = orderIssuer.GetIntendedTarget(i);
                    float width = 25f;
                    GUI.DrawTexture(new Rect(
                        tar.x - width / 2.0f,
                        Screen.height - (tar.y + width / 2.0f) + bounceAnimation * 12f,
                        width,
                        width),
                        arrowTexture);
                    ++i;
                });
            }
        }
        #endregion

        #region Per Unit Input Fields
        if (selectedUnits.Count != 0)
        {
            int prevFontSize = GUI.skin.font.fontSize;
            int fontsize = (int)(13.0f / 1267.0f * (float)Screen.height);
            GUI.skin.label.fontSize 
                = GUI.skin.button.fontSize 
                = GUI.skin.textField.fontSize
                = fontsize;
            int i = 0;
            ISelectable first = selectedUnits.GetUnit();
            bool hasChanged = false;

            float totalHeight = ProjectConstants.bottomPanel.height * 0.8f;
            float rectHeight = totalHeight / first.GuiFieldCount;
            float y = ProjectConstants.bottomPanel.y + (ProjectConstants.bottomPanel.height - totalHeight) / 2.0f;
            float gap = 0.1337f * rectHeight;
            float x = (float)Screen.width * 0.05f;
            float totalWidth = (float)Screen.width * 0.15f;
            first.ForEachGuiField((key, value) =>
            {
                float labelWidth = totalWidth * 0.6f;
                Rect rect = new Rect(x, (y + i * rectHeight) + gap / 2.0f, labelWidth, rectHeight - gap);
                ++i;
                GUI.Label(rect, key);
                rect.x += labelWidth;
                rect.width = totalWidth * 0.2f;
                return GUI.TextField(rect, value);
            }, 
            () => hasChanged = hasChanged 
            || GUI.Button(new Rect(x + totalWidth * 0.8f, (y + (i-1) * rectHeight) + gap / 2.0f, totalWidth * 0.2f, rectHeight - gap), "Enter"));

            if (hasChanged)
            {
                selectedUnits.ForEach(item =>
                {
                    if (first != item)
                    {
                        item.ForEachGuiField((key, value) => first.GetExposedGuiField(key).ToString(), () => true);
                    }
                });
            }
            GUI.skin.label.fontSize
                = GUI.skin.button.fontSize
                = GUI.skin.textField.fontSize
                = prevFontSize;
        }
        #endregion

        #region State Buttons
        if (selectedUnits.Count != 0)
        {
            int length = states.Length;
            for (int i = 0; i < length; i++)
            {
                if (GUI.Button(states[i].Rect, states[i].Type.Name))
                {
                    selectedUnits.ForEach(item =>
                    {
                        item.Steer = states[i].Type;
                    });
                }
            }
        }
        #endregion

        #region State Pointer Arrow
        bool isAllSameSteerMode = false;
        System.Type steerRef = null;
        bool isFirst = true;
        bool isBreak = false;
        selectedUnits.ForEach(x => 
        {
            if (isBreak)
                return;
            if (isFirst)
            {
                isFirst = false;
                steerRef = x.Steer;
            }
            bool wasTrue = isAllSameSteerMode;
            isAllSameSteerMode = x.Steer == steerRef;
            if (wasTrue && !isAllSameSteerMode)
                isBreak = true;
        });
        
        if (isAllSameSteerMode && steerRef != null)
        {
            SteerData curState = states.Where(x => x.Type.Equals(steerRef)).First();
            arrowRect.x = curState.Rect.x + 0.5f * curState.Rect.width - 0.5f * arrowRect.width;
            arrowRect.y = arrowHeight + bounceAnimation * 20.0f;
            GUI.DrawTexture(arrowRect, arrowTexture);
        }
        #endregion

        #region Follow Unit Hover Tooltip
        if (selectedUnits.Count != 0)
        {
            GameObject hovering = MouseGetter.SelectObject(selectedUnits.SelectableLayer);
            if (hovering != null)
            {
                Vector2 offset = new Vector2(10.0f, -10.0f);
                Vector2 mousePos = (Vector2)Input.mousePosition + offset;
                GUI.Label(new Rect(mousePos.x, Screen.height - mousePos.y, 150.0f, 60.0f), "Right Click To Follow");
            }
        }
        #endregion

        #region Exit Button
        {
            float width = 69f;
            if (GUI.Button(new Rect(Screen.width - width, 0.0f, width, 42f), "Quit"))
            {
                Application.Quit();
            }
        }
        #endregion
    }

    void InitButtonRects()
    {
        System.Type[] allSteers = RockUtil.GetAllSubclasses<LocomotionState>();
        states = new SteerData[allSteers.Length];
        for (int i = 0; i < states.Length; i++)
        {
            states[i] = new SteerData(allSteers[i]);
        }

        int rectCount = states.Length;

        float screenWidth = (float)Screen.width * 0.6f;
        float totalWidth = screenWidth * 0.8f;
        float width = totalWidth / (float)rectCount;
        float startX = (screenWidth - totalWidth) / 2.0f + 0.4f * (float)Screen.width;
        float height = ProjectConstants.bottomPanel.height * 0.5f;
        float y = ProjectConstants.bottomPanel.y + (ProjectConstants.bottomPanel.height - height) / 2.0f;
        float gap = 0.1337f * width;

        for (int i = 0; i < rectCount; i++)
        {
            float x = (float)i / (float)rectCount * totalWidth + startX;
            states[i].Rect = new Rect(x + gap / 2.0f, y, width - gap, height);
        }

        arrowHeight = y - height / 2.0f;
    }
}
