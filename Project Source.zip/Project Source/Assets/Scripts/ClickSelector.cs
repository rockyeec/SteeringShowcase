using rockUtil;
using UnityEngine;

public class ClickSelector : MonoBehaviour
{
    [Header("Components")]
    [SerializeField] SelectedUnits selectedUnits = null;

    public static event System.Action OnSelect = delegate { };
    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            bool isNotClickingUI = Input.mousePosition.y > ProjectConstants.bottomPanel.height;
            if (isNotClickingUI)
            {
                selectedUnits.Clear();
                ClickSelect();
            }
        }
    }
    private void ClickSelect()
    {
        GameObject selected = MouseGetter.SelectObject(selectedUnits.SelectableLayer);
        if (selected != null)
        {
            var iSelectable = selected.GetComponent<ISelectable>();
            if (iSelectable != null)
            {
                selectedUnits.Add(iSelectable);
                OnSelect();
            }
        }
    }
}
