using UnityEngine;

[RequireComponent(typeof(Animator))]
public class FootIK : MonoBehaviour
{
    [SerializeField] Animator animator = null;
    [SerializeField] float footRangeHeight = 1.0f;

    Transform[] feet;
    readonly AvatarIKGoal[] footGoals = new AvatarIKGoal[2] { AvatarIKGoal.LeftFoot, AvatarIKGoal.RightFoot };
    float footHeight = 0.25f;
    float currWeight = 0.0f;

    private void Reset()
    {
        animator = GetComponent<Animator>();
    }

    private void Awake()
    {
        if (animator == null)
            animator = GetComponent<Animator>();

        feet = new Transform[2]
        {
            animator.GetBoneTransform(HumanBodyBones.LeftFoot),
            animator.GetBoneTransform(HumanBodyBones.RightFoot)
        };

        footHeight = transform.InverseTransformPoint(feet[0].position).y;
    }

    private void OnAnimatorIK(int layerIndex)
    {
        //#if UNITY_EDITOR
        //        Stopwatch stopWatch = new Stopwatch();
        //        stopWatch.Start();
        //#endif
        
        //HandleFootSteps();

        float moveAmount = animator.GetFloat(HashedStrings.moveZ);
        currWeight = 1.0f - Mathf.InverseLerp(0.0f, 0.15f, moveAmount);

        for (int i = 0; i < 2; i++)
        {
            animator.SetIKPositionWeight(footGoals[i], currWeight);
            animator.SetIKRotationWeight(footGoals[i], currWeight);

            if (Mathf.Approximately(currWeight, 0.0f))
                continue;

            if (Physics.Raycast(
                feet[i].position + footRangeHeight * Vector3.up, 
                Vector3.down, 
                out RaycastHit hit, 
                footRangeHeight * 2.0f, 
                ProjectConstants.groundLayer))
            {
                animator.SetIKPosition(footGoals[i], hit.point + Vector3.up * footHeight);

                Vector3 right = Vector3.Cross(feet[i].up, hit.normal);
                Vector3 forward = Vector3.Cross(hit.normal, right);

                animator.SetIKRotation(footGoals[i], Quaternion.LookRotation(forward, hit.normal));
            }
        }

        //#if UNITY_EDITOR
        //        stopWatch.Stop();
        //        // Get the elapsed time as a TimeSpan value.
        //        System.TimeSpan ts = stopWatch.Elapsed;
        //        print(ts);
        //#endif
    }

    //readonly int[] footstepsfxs = new int[5]
    //    {
    //        "footstep_0".GetHashCode(),
    //        "footstep_1".GetHashCode(),
    //        "footstep_2".GetHashCode(),
    //        "footstep_3".GetHashCode(),
    //        "footstep_4".GetHashCode()
    //    };

    //readonly bool[] isDown = new bool[2] { false, false };
    //void HandleFootSteps()
    //{
    //    for (int i = 0; i < 2; i++)
    //    {
    //        float currY = transform.InverseTransformPoint(feet[i].transform.position).y;
    //        bool isTouchGround = currY < 0.2f;
    //        if (isDown[i])
    //        {
    //            if (!isTouchGround)
    //            {
    //                isDown[i] = false;
    //            }
    //        }
    //        else
    //        {
    //            if (isTouchGround)
    //            {
    //                isDown[i] = true;
    //                //Manager_Pool.PoolOut(ReadOnlies.Particle_Dust, feet[i].position, Quaternion.identity);
    //                //SfxPlayer.Play(footstepsfxs.GetRandom(), feet[i].position);
    //            }
    //        }
    //    }
    //}
}
