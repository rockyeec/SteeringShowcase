using System.Collections;
using UnityEngine;
using rockUtil;

[RequireComponent(typeof(MeshCollider))]
[RequireComponent(typeof(Rigidbody))]
public class RectangleSelector : MonoBehaviour
{
    #region Serialized fields (Components)
    [SerializeField] TopDownCameraController topDownCameraController = null;
    [SerializeField] SelectedUnits selected = null;
    [SerializeField] MeshCollider meshCollider = null;
    [SerializeField] Rigidbody rigidBody = null;
    #endregion

    #region 2D fields
    Vector2 beginScreenPoint, endScreenPoint;
    readonly Vector2[] screenPoints = new Vector2[4];
    Rect guiBox = new Rect();
    #endregion

    #region 3D fields
    Mesh boxMesh;
    readonly Vector3[] vertices = new Vector3[8];
    readonly int[] triangles = new int[36] { 0, 1, 5, 5, 4, 0, 3, 7, 6, 6, 2, 3, 0, 4, 7, 7, 3, 0, 1, 2, 6, 6, 5, 1, 3, 2, 1, 1, 0, 3, 4, 5, 6, 6, 7, 4 };
    #endregion

    #region Physics fields
    Coroutine overlapMeshCoroutine = null;
    readonly WaitForFixedUpdate waitForFixedUpdate = new WaitForFixedUpdate();
    #endregion

    public static event System.Action OnSelect = delegate { };

    private void Reset()
    {
        topDownCameraController = FindObjectOfType<TopDownCameraController>();
        selected = FindObjectOfType<SelectedUnits>();
        meshCollider = GetComponent<MeshCollider>();
        rigidBody = GetComponent<Rigidbody>();
    }

    private void Awake()
    {
        if (topDownCameraController == null)
            topDownCameraController = FindObjectOfType<TopDownCameraController>();
        if (selected == null)
            selected = FindObjectOfType<SelectedUnits>();
        if (meshCollider == null)
            meshCollider = GetComponent<MeshCollider>();
        if (rigidBody == null)
            rigidBody = GetComponent<Rigidbody>();

        rigidBody.isKinematic = true;
        rigidBody.useGravity = false;
        rigidBody.constraints = RigidbodyConstraints.FreezeAll;

        meshCollider.convex = true;
        meshCollider.isTrigger = true;

        boxMesh = new Mesh();

        transform.SetParent(null);
        transform.position = Vector3.zero;
        transform.localScale = Vector3.one;
        transform.rotation = Quaternion.identity;
        gameObject.layer = 2; // ignore Raycast
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
            MouseDown();
        if (Input.GetMouseButton(0))
            MouseDrag();
        if (Input.GetMouseButtonUp(0))
            MouseUp();
    }

    private void MouseDown()
    {
        if (topDownCameraController != null)
            topDownCameraController.enabled = false;
        beginScreenPoint = Input.mousePosition;
    }
    private void MouseDrag()
    {
        endScreenPoint = Input.mousePosition;
    }
    private void MouseUp()
    {
        if (topDownCameraController != null)
            topDownCameraController.enabled = true;

        bool isBoxMeshTooSmall = (endScreenPoint - beginScreenPoint).sqrMagnitude < 20.0f;
        if (isBoxMeshTooSmall)
            return;

    #region 3D Modeling
        screenPoints[0].x = Mathf.Min(beginScreenPoint.x, endScreenPoint.x);
        screenPoints[0].y = Mathf.Min(beginScreenPoint.y, endScreenPoint.y);
        screenPoints[1].x = Mathf.Min(beginScreenPoint.x, endScreenPoint.x);
        screenPoints[1].y = Mathf.Max(beginScreenPoint.y, endScreenPoint.y);
        screenPoints[2].x = Mathf.Max(beginScreenPoint.x, endScreenPoint.x);
        screenPoints[2].y = Mathf.Max(beginScreenPoint.y, endScreenPoint.y);
        screenPoints[3].x = Mathf.Max(beginScreenPoint.x, endScreenPoint.x);
        screenPoints[3].y = Mathf.Min(beginScreenPoint.y, endScreenPoint.y);

        for (int i = 0; i < 4; i++)
        {          
            vertices[i] = MouseGetter.GetGroundPoint(screenPoints[i]) + MouseGetter.Ray.direction * 10.0f;
            vertices[i + 4] = MouseGetter.Ray.origin;
        }

        boxMesh.vertices = vertices;
        boxMesh.triangles = triangles;
    #endregion

        if (overlapMeshCoroutine != null)
            StopCoroutine(overlapMeshCoroutine);
        overlapMeshCoroutine = StartCoroutine(OverlapMesh());
    }
    IEnumerator OverlapMesh()
    {
        try { meshCollider.sharedMesh = boxMesh; } catch { meshCollider.sharedMesh = null; yield break; }       
        yield return waitForFixedUpdate;
        meshCollider.sharedMesh = null;
        OnSelect();
    }
    
    private void OnTriggerEnter(Collider other)
    {
        var unit = other.GetComponent<ISelectable>();
        if (unit == null) return;
        selected.Add(unit);
    }

    private void OnGUI()
    {
        if (Input.GetMouseButton(0))
        {
            guiBox.x = Mathf.Min(endScreenPoint.x, beginScreenPoint.x);
            guiBox.y = Screen.height - Mathf.Max(endScreenPoint.y, beginScreenPoint.y);
            guiBox.width = Mathf.Abs(endScreenPoint.x - beginScreenPoint.x);
            guiBox.height = Mathf.Abs(endScreenPoint.y - beginScreenPoint.y);
            GUI.Box(guiBox, string.Empty);
        }
    }
}
