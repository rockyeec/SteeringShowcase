using UnityEngine;
using System;
using System.Collections.Generic;

public class SteeringController : MonoBehaviour, IVehicle, ICanArrive, ICanWander, ISelectable
{
#region Serialized Fields
    [Header("Vehicle Fields")]
    [SerializeField] float mass = 1.0f;
    [SerializeField] float maxForce = 0.05f;
    [SerializeField] float maxSpeed = 0.05f;
    [SerializeField][Range(0.0f, 1.0f)] float speedFactor = 1.0f;

    [Header("Arrive Fields")]
    [SerializeField] float arriveRadius = 2.5f;

    [Header("Wander Fields")]
    [SerializeField] float wanderDecisionInterval = 0.69f;
    [SerializeField] float wanderRadius = 1.337f;
    [SerializeField] float wanderDistanceAhead = 4.20f;

    [Header("RTS Selection Fields")]
    [SerializeField] GameObject selectionCircle = null;
    [SerializeField] float followStopDistance = 1.0f;
#endregion

#region IVehicle Interface Members
    public Vector3 Target => pursuitVictim == null ? target : pursuitVictim.Position;
    public float Mass => mass;
    public float MaxForce => maxForce;
    public float MaxSpeed => maxSpeed;
    public float SpeedFactor => Mathf.Max(1e-1f, speedFactor);
    public Vector3 Position 
    { 
        get => transform.position; 
        set => transform.position = value; 
    }
    public Vector3 Velocity { get; set; }
    public Quaternion Rotation 
    {
        get => transform.rotation;
        set => transform.rotation = value; 
    }
#endregion

#region ICanArrive Interface Members
    public float ArriveRadius => Mathf.Max(1e-3f, arriveRadius);
#endregion

#region ICanWander Interface Members
    public float WanderDecisionInterval => wanderDecisionInterval;
    public float WanderRadius => wanderRadius;
    public float WanderDistanceAhead => wanderDistanceAhead;
    #endregion

#region ISelectable Interface Members
    public void OnSelect()
    {
        foreach (var item in exposedGuiFields)
        {
            item.Value.ResetParse();
        }
        selectionCircle.SetActive(true);
    }
    public void OnDeselect()
    {
        selectionCircle.SetActive(false);
    }
    public void Go(Vector3 point)
    {
        target = point;
        isSetTarget = true;
    }
    public void Pursue(IVehicle victim)
    {
        pursuitVictim = victim;
        isSetTarget = victim != null;
    }
    public Type Steer
    {
        get => currentSteer;
        set
        {
            currentSteer = value;
            isSetSteerState = true;
        }
    }
    // temporary GUI exposure
    class ExposedGUI
    {
        public Action<float> Set { get; }
        public Func<float> Get { get; }
        public string TryParse { get; set; }
        public ExposedGUI(Action<float> set, Func<float> get)
        {
            Set = set;
            Get = get;
            ResetParse();
        }
        public void ResetParse() => TryParse = Get.Invoke().ToString();
    }
    readonly Dictionary<string, ExposedGUI> exposedGuiFields = new Dictionary<string, ExposedGUI>();
    public int GuiFieldCount => exposedGuiFields.Count;
    public void ForEachGuiField(Func<string, string, string> onFieldUpdate, Func<bool> onEnter)
    {                               
        foreach (var item in exposedGuiFields)
        {
            item.Value.TryParse = onFieldUpdate(item.Key, item.Value.TryParse);

            if (onEnter())
            {
                if (float.TryParse(item.Value.TryParse, out float value))
                {
                    exposedGuiFields[item.Key].Set.Invoke(value);
                }
                else
                {
                    exposedGuiFields[item.Key].ResetParse();
                }
            }
        }
    }    
    public float GetExposedGuiField(string key) => exposedGuiFields[key].Get.Invoke();
#endregion

#region Private Properties
    StateMachine StateMachine { get; } = new StateMachine();
    Vector3 Displacement => Target - Position;
#endregion

#region Private Fields
    Vector3 target;
    Type currentSteer;
    bool isSetSteerState;
    bool isSetTarget;
    IVehicle pursuitVictim;    
#endregion

    private void Awake()
    {
        var animator = GetComponentInChildren<Animator>();

        var idleState = new IdleState(this, animator);
        var seekState = new SeekState(this, animator);
        var fleeState = new FleeState(this, animator);
        var pursuitState = new PursuitState(this, animator);
        var evadeState = new EvadeState(this, animator);
        var arriveState = new ArriveState(this, animator, this);
        var wanderState = new WanderState(this, animator, this, value => target = value);
        var flockState = new FlockState(this, animator);

        StateMachine.AddAnyTransition(seekState   , () => IsStateChange( typeof(SeekState) ));
        StateMachine.AddAnyTransition(fleeState   , () => IsStateChange( typeof(FleeState) ));
        StateMachine.AddAnyTransition(pursuitState, () => IsStateChange( typeof(PursuitState) ));
        StateMachine.AddAnyTransition(evadeState  , () => IsStateChange( typeof(EvadeState) ));
        StateMachine.AddAnyTransition(arriveState , () => IsStateChange( typeof(ArriveState) ));
        StateMachine.AddAnyTransition(wanderState , () => IsStateChange( typeof(WanderState) ));
        StateMachine.AddAnyTransition(flockState  , () => IsStateChange( typeof(FlockState) ));

        StateMachine.AddTransition(idleState   , seekState   , () => IsStartSteer(typeof(SeekState)));
        StateMachine.AddTransition(seekState   , idleState   , () => IsStopSteer(typeof(SeekState)));
        StateMachine.AddTransition(idleState   , pursuitState, () => IsStartSteer(typeof(PursuitState)));
        StateMachine.AddTransition(pursuitState, idleState   , () => IsStopSteer(typeof(PursuitState)));
        StateMachine.AddTransition(idleState   , arriveState , () => IsStartSteer(typeof(ArriveState)));
        StateMachine.AddTransition(arriveState , idleState   , () => IsStopSteer(typeof(ArriveState)));
        StateMachine.SetState(idleState);

        bool IsStateChange(Type state) => currentSteer.Equals(state) && isSetSteerState;
        bool IsStartSteer(Type state) => currentSteer.Equals(state) && ( isSetTarget || IsStartFollow() );
        bool IsStopSteer(Type state) => currentSteer.Equals(state) && ( Displacement.sqrMagnitude < 1e-2f || IsStopFollow() );
        bool IsStartFollow() => Displacement.IsLongerThan(followStopDistance + 0.15f) && pursuitVictim != null;
        bool IsStopFollow() => Displacement.IsShorterThan(followStopDistance) && pursuitVictim != null;

        currentSteer = typeof(ArriveState);
        target = VehicleUtility.GetGroundPoint(transform.position + 1e-1f * Vector3.forward);
        isSetSteerState = true;

        // temp GUI exposure
        exposedGuiFields.Add("Mass",                     new ExposedGUI(value => mass = value                  , () => mass));
        exposedGuiFields.Add("Max Speed",                new ExposedGUI(value => maxSpeed = value              , () => maxSpeed));
        exposedGuiFields.Add("Max Force",                new ExposedGUI(value => maxForce = value              , () => maxForce));
        exposedGuiFields.Add("Walk / Run (0, 1]",        new ExposedGUI(value => speedFactor = value           , () => speedFactor));
        exposedGuiFields.Add("Arrive Radius",            new ExposedGUI(value => arriveRadius = value          , () => arriveRadius));
        exposedGuiFields.Add("Wander Decision Interval", new ExposedGUI(value => wanderDecisionInterval = value, () => wanderDecisionInterval));
        exposedGuiFields.Add("Wander Radius",            new ExposedGUI(value => wanderRadius = value          , () => wanderRadius));
        exposedGuiFields.Add("Wander Distance Ahead",    new ExposedGUI(value => wanderDistanceAhead = value   , () => wanderDistanceAhead));
    }

    private void FixedUpdate()
    {
        StateMachine.Tick(Time.fixedDeltaTime);
        isSetTarget = false;
        isSetSteerState = false;
    }    
}