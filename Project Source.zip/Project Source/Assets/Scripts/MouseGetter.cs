using UnityEngine;
namespace rockUtil
{
    public static class MouseGetter
    {
#region CUSTOMIZE_ACCORDING_TO_PROJECT

        static int GroundLayer => ProjectConstants.groundLayer;// 1 << 0;
        static float RayLength => 1337.0f;

#endregion

        static Camera mainCamera;
        static Ray ray;
        static RaycastHit hit;
        public static Camera Camera
        {
            get
            {
                if (mainCamera == null)
                    mainCamera = Camera.main;
                return mainCamera;
            }
        }
        public static Vector2 ViewportPoint 
            => Camera.ScreenToViewportPoint(Input.mousePosition);
        public static Vector3? Point
        {
            get
            {
                ray = Camera.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out hit, RayLength, GroundLayer))
                    return hit.point;
                else
                    return null;
            }
        }
        public static Ray Ray => ray;
        public static RaycastHit Hit => hit;
        public static Vector3? GetNullableGroundPoint(Vector2 screenPoint)
        {
            ray = Camera.ScreenPointToRay(screenPoint);
            if (Physics.Raycast(ray, out hit, RayLength, GroundLayer))
                return hit.point;
            else
                return null;
        }
        public static Vector3? GetNullableGroundPoint(Vector3 worldPoint, float rayLength = 3.0f)
        {
            ray.origin = worldPoint + 0.5f * rayLength * Vector3.up;
            ray.direction = Vector3.down;
            if (Physics.Raycast(ray, out hit, RayLength, GroundLayer))
                return hit.point;
            else
                return null;
        }
        public static Vector3 GetGroundPoint(Vector2 screenPoint)
        {
            ray = Camera.ScreenPointToRay(screenPoint);
            if (Physics.Raycast(ray, out hit, RayLength, GroundLayer))
                return hit.point;
            else
                return ray.origin + RayLength * ray.direction;
        }
        public static Vector2 WorldToScreenPoint(Vector3 worldPoint)
            => Camera.WorldToScreenPoint(worldPoint);
        public static GameObject SelectObject(LayerMask layerMask)
        {
            ray = Camera.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, RayLength, layerMask))
                return hit.collider.gameObject;
            else
                return null;
        }
    }
}