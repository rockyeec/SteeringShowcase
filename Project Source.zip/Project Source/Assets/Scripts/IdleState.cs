using UnityEngine;

public class IdleState : IState
{
    Animator Animator { get; }
    IVehicle Vehicle { get; }
    public IdleState(IVehicle vehicle, Animator animator)
    {
        Vehicle = vehicle;
        Animator = animator;
    }
    public void OnEnter()
    {
        Animator.CrossFade(
            Vehicle.Velocity.IsLongerThan(4.20f) 
            ? HashedStrings.brake 
            : HashedStrings.idle, 
            0.25f);
        Vehicle.Velocity = Vector3.zero;
    }
    public void OnExit() { }
    public void Tick(in float deltaTime) 
    {
        if (Animator.GetFloat(HashedStrings.moveZ) > 1e-2f)        
            Animator.SetFloat(HashedStrings.moveZ, 0.0f, 0.25f, deltaTime);        
    }
}