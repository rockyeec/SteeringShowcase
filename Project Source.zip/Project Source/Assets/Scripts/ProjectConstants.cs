using UnityEngine;

public static class ProjectConstants
{
    public static readonly int groundLayer = 1 << 0;
    public static readonly Rect bottomPanel = new Rect(0.0f, Screen.height * 0.75f, Screen.width, Screen.height * 0.25f);
}
