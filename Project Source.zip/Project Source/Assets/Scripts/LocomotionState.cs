using UnityEngine;

public abstract class LocomotionState : IState
{
    protected Animator Animator { get; }
    protected IVehicle Vehicle { get; }

    public LocomotionState(IVehicle vehicle, Animator animator)
    {
        Vehicle = vehicle;
        Animator = animator;
    }

    public virtual void OnEnter() 
        => Animator.CrossFade(HashedStrings.locomotion, 0.25f);
    public virtual void OnExit() { }

    public virtual void Tick(in float deltaTime) 
        => Animator.SetFloat(HashedStrings.moveZ, Vehicle.Velocity.magnitude / Vehicle.MaxSpeed);
}
