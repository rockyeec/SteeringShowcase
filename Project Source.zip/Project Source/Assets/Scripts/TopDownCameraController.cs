using UnityEngine;

namespace rockUtil
{
    // How to use ? Just attach this to an empty Game Object, the Reset() Method takes care of everything on attach
    // ************************************************************************************************************
    // *    this.transform acts as both the Truck and Dolly (left right forward backward translation)             *
    // *    the Pedestal is a child of this.transform (up down translation)                                       *
    // *    the Tilt is a child of the Pedestal (up down rotation)                                                *
    // ************************************************************************************************************
    public class TopDownCameraController : MonoBehaviour
    {
        [Header("Values")]
        [SerializeField] float truckSpeed = 13.37f;
        [SerializeField] float minPitch = 10.0f;
        [SerializeField] float maxPitch = 50.0f;
        [SerializeField] float minHeight = 1.0f;
        [SerializeField] float maxHeight = 6.9f;
        [SerializeField] float scrollSmoothTime = 0.15f;

        [Header("Ground Collision Check")]
        [SerializeField] float rayLength = 6.9f;

        [Header("Camera Move Transforms")]
        [SerializeField] Transform pedestal = null;
        [SerializeField] Transform tilt = null;

        Camera Camera => MouseGetter.Camera;
        int GroundLayer => ProjectConstants.groundLayer;
        float ScrollPercent { get; set; } = 1.0f;

        float tiltVel, pedestalVel;
        RaycastHit hit;

        private void Reset()
        {
            name = "Top Down Camera Controller";
            transform.position = transform.position.With(y: 0.0f);
            AssignTransforms("Pedestal", ref pedestal, transform, Vector3.zero.With(y:maxHeight), Quaternion.identity);
            AssignTransforms("Tilt", ref tilt, pedestal, Vector3.zero, Quaternion.Euler(maxPitch, 0.0f, 0.0f));
        }
        void AssignTransforms(string transformName, ref Transform thisTransform, Transform parent, Vector3 localPosition, Quaternion localRotation)
        {
            if (thisTransform == null)
            {
                if (parent.childCount != 0)
                {
                    thisTransform = parent.GetChild(0);
                }
                else
                {
                    thisTransform = new GameObject().transform;
                    thisTransform.SetParent(parent);
                }
                thisTransform.name = transformName;
                thisTransform.localPosition = localPosition;
                thisTransform.localRotation = localRotation;
            }
        }

        private void Awake()
        {
            Camera.transform.SetParent(tilt);
            Camera.transform.localPosition = Vector3.zero;
            Camera.transform.localRotation = Quaternion.identity;

            transform.position = transform.position.With(y: 0.0f);
            pedestal.localPosition = Vector3.zero.With(y: maxHeight);
            tilt.localEulerAngles = Vector3.zero.With(x: maxPitch);
        }

        private void Update()
        {
            ScrollPercent -= Input.GetAxis("Mouse ScrollWheel");
            ScrollPercent = Mathf.Clamp01(ScrollPercent);
        }

        private void FixedUpdate()
        {
            float deltaTime = Time.fixedDeltaTime;
            HandleTruckAndDolley(in deltaTime);
            HandleTiltAndPedestal();
        }
        
        void HandleTruckAndDolley(in float deltaTime)
        {
            Vector2 mouseViewportPoint = MouseGetter.ViewportPoint - Vector2.one * 0.5f;
            float hor = Mathf.Sign(mouseViewportPoint.x) * Mathf.InverseLerp(0.420f, 0.5f, (Mathf.Abs(mouseViewportPoint.x)));
            float ver = Mathf.Sign(mouseViewportPoint.y) * Mathf.InverseLerp(0.420f, 0.5f, (Mathf.Abs(mouseViewportPoint.y)));
            transform.Translate(deltaTime * truckSpeed * new Vector3(hor, 0.0f, ver));

            if (Physics.Raycast(
                transform.position + 0.5f * rayLength * Vector3.up,
                Vector3.down,
                out hit, 
                rayLength,
                GroundLayer))
            {
                transform.position = hit.point;
            }
        }
        void HandleTiltAndPedestal()
        {
            float pedestalY = Mathf.LerpUnclamped(minHeight, maxHeight, ScrollPercent);
            float tiltX = Mathf.LerpUnclamped(minPitch, maxPitch, ScrollPercent);

            float smoothPedestalY = Mathf.SmoothDamp(pedestal.localPosition.y, pedestalY, ref pedestalVel, scrollSmoothTime);
            float smoothTiltX = Mathf.SmoothDampAngle(tilt.localEulerAngles.x, tiltX, ref tiltVel, scrollSmoothTime);

            pedestal.localPosition = Vector3.zero.With(y: smoothPedestalY);
            tilt.localEulerAngles = Vector3.zero.With(x: smoothTiltX);
        }
    }
}