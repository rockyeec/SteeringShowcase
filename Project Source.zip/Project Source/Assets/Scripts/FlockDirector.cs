using System.Collections.Generic;
using UnityEngine;
using System;

public class FlockDirector : MonoBehaviour
{
    [Header("Flocking Parameters")]
    [SerializeField] float size = 1.0f;
    [SerializeField] float neighbourRadius = 6.0f;

    [Header("Flocking Influence Parameters")]
    [SerializeField] float separateMultiplier = 1.0f;
    [SerializeField] float alignMultiplier = 1.0f;
    [SerializeField] float cohesionMultiplier = 1.0f;
    [SerializeField][Range(-1.0f, 1.0f)] float seekMultiplier = 0.2f;

    [Header("Components For GUI")]
    [SerializeField] SelectedUnits selectedUnits = null;

    readonly static List<IVehicle> boids = new List<IVehicle>();
    public static void Add(IVehicle vehicle) => boids.Add(vehicle);
    public static void Remove(IVehicle vehicle) => boids.Remove(vehicle);

    void FixedUpdate()
    {
        foreach (var item in boids)
        {
            Vector3 seek = Vector3.ClampMagnitude( (item.Target - item.Position).normalized * item.MaxSpeed, item.MaxForce );

            Vector3 steeringForce = GetSteeringForce(item) + seek * seekMultiplier;
            VehicleUtility.UpdateFromSteeringForce(item, steeringForce, Time.fixedDeltaTime);
        }
    }

    Vector3 GetSteeringForce(IVehicle boid)
    {
        float distancingRadius = size * 2.0f;
        Vector3 sumSeparate = Vector3.zero;
        Vector3 sumAlign = Vector3.zero;
        Vector3 sumCohere = Vector3.zero;
        int countSeparate = 0;
        int countAlignAndCohere = 0;

        foreach (var other in boids)
        {
            if (other == boid) continue;

            float distance = Vector3.Distance(boid.Position, other.Position);

            if (distance > 0.0f)
            {
                if (distance < distancingRadius)
                {
                    Vector3 offset = boid.Position - other.Position;
                    Vector3 direction = offset.normalized;

                    Vector3 separation = direction / distance;

                    sumSeparate += separation;
                    ++countSeparate;
                }
                if (distance < neighbourRadius)
                {
                    sumAlign += other.Velocity;
                    sumCohere += other.Position;
                    ++countAlignAndCohere;
                }
            }
        }

        Vector3 steeringForce = Vector3.zero;
        if (countSeparate > 0)
        {
            Vector3 desiredVelocity = boid.SpeedFactor * boid.MaxSpeed * (sumSeparate / countSeparate).normalized;
            Vector3 steer = desiredVelocity - boid.Velocity;
            steeringForce += (separateMultiplier * Vector3.ClampMagnitude(steer, boid.MaxForce));
        }
        if (countAlignAndCohere > 0)
        {
            {
                Vector3 alignVelocity = sumAlign / countAlignAndCohere;
                Vector3 desiredVelocity = boid.SpeedFactor * boid.MaxSpeed * alignVelocity.normalized;
                Vector3 steer = desiredVelocity - boid.Velocity;
                steeringForce += (alignMultiplier * Vector3.ClampMagnitude(steer, boid.MaxForce));
            }

            {
                Vector3 averagePosition = sumCohere / countAlignAndCohere;
                Vector3 desiredDirection = averagePosition - boid.Position;
                Vector3 desiredVelocity = boid.SpeedFactor * boid.MaxSpeed * desiredDirection.normalized;
                Vector3 steer = desiredVelocity - boid.Velocity;
                steeringForce += (cohesionMultiplier * Vector3.ClampMagnitude(steer, boid.MaxForce));
            }
        }

        return steeringForce;
    }

    // temp GUI exposure
    class ExposedGUI
    {
        public Action<float> Set { get; }
        public Func<float> Get { get; }
        public string TryParse { get; set; }
        public ExposedGUI(Action<float> set, Func<float> get)
        {
            Set = set;
            Get = get;
            ResetParse();
        }
        public void ResetParse() => TryParse = Get.Invoke().ToString();
    }
    readonly Dictionary<string, ExposedGUI> exposedGuiFields = new Dictionary<string, ExposedGUI>();

    private void Awake()
    {
        exposedGuiFields.Add("Boid Size", new ExposedGUI(value => size = value, () => size));
        exposedGuiFields.Add("Neighbour Radius", new ExposedGUI(value => neighbourRadius = value, () => neighbourRadius));
        exposedGuiFields.Add("Separate Multiplier", new ExposedGUI(value => separateMultiplier = value, () => separateMultiplier));
        exposedGuiFields.Add("Align Multiplier", new ExposedGUI(value => alignMultiplier = value, () => alignMultiplier));
        exposedGuiFields.Add("Cohesion Multiplier", new ExposedGUI(value => cohesionMultiplier = value, () => cohesionMultiplier));
        exposedGuiFields.Add("Seek Multiplier (set negative to flee)", new ExposedGUI(value => seekMultiplier = value, () => seekMultiplier));
    }

    private void OnGUI()
    {
        if (selectedUnits.Count == 0)
            return;

        int prevFontSize = GUI.skin.font.fontSize;
        int fontsize = (int)(13.0f / 1267.0f * (float)Screen.height);
        GUI.skin.label.fontSize
            = GUI.skin.button.fontSize
            = GUI.skin.textField.fontSize
            = fontsize;

        float totalHeight = ProjectConstants.bottomPanel.height * 0.8f;
        float rectHeight = totalHeight / 6;
        float y = ProjectConstants.bottomPanel.y + (ProjectConstants.bottomPanel.height - totalHeight) / 2.0f;
        float gap = 0.1337f * rectHeight;
        float x = (float)Screen.width * 0.25f;
        float totalWidth = (float)Screen.width * 0.15f;
        float labelWidth = totalWidth * 0.6f;

        int i = 0;
        foreach (var item in exposedGuiFields)
        {
            Rect rect = new Rect(x, (y + i * rectHeight) + gap / 2.0f, labelWidth, rectHeight - gap);
            GUI.Label(rect, item.Key);
            rect.x += labelWidth;
            rect.width = totalWidth * 0.2f;
            item.Value.TryParse = GUI.TextField(rect, item.Value.TryParse);

            if (GUI.Button(new Rect(x + totalWidth * 0.8f, (y + i * rectHeight) + gap / 2.0f, totalWidth * 0.2f, rectHeight - gap), "Enter"))
            {
                if (float.TryParse( item.Value.TryParse, out float result) )
                {
                    item.Value.Set.Invoke(result);
                }
                else
                {
                    item.Value.ResetParse();
                }
            }
            ++i;
        }

        GUI.skin.label.fontSize
            = GUI.skin.button.fontSize
            = GUI.skin.textField.fontSize
            = prevFontSize;
    }
}
