using System.Collections.Generic;
using UnityEngine;

public interface ISelectable
{
    void OnSelect();
    void OnDeselect();
    void Go(Vector3 point);
    void Pursue(IVehicle victim);
    System.Type Steer { get; set; }
    Vector3 Target { get; }

    //temp: for GUI usage
    Vector3 Position { get; }
    /// <summary></summary>
    /// <param name="onFieldUpdate">string name, string value, string return</param>
    /// <param name="onEnter">enter key pressed</param>
    void ForEachGuiField(System.Func<string, string, string> onFieldUpdate, System.Func<bool> onEnter);
    float GetExposedGuiField(string key);
    int GuiFieldCount { get; }
}

public class SelectedUnits : MonoBehaviour
{
    [SerializeField] LayerMask selectableLayer = 1 << 8;
    readonly List<ISelectable> selectedUnits = new List<ISelectable>();
    public int Count => selectedUnits.Count;
    public LayerMask SelectableLayer => selectableLayer;

    public void Add(ISelectable value)
    {
        if (selectedUnits.Contains(value))
            return;
        selectedUnits.Add(value);
        value.OnSelect();
    }
    public void Remove(ISelectable value)
    {
        value.OnDeselect();
        selectedUnits.Remove(value);
    }
    public void Clear()
    {
        foreach (var item in selectedUnits)
        {
            item.OnDeselect();
        }
        selectedUnits.Clear();
    }
    public void ForEach(System.Action<ISelectable> doAction)
    {
        foreach (var item in selectedUnits)
        {
            doAction(item);
        }
    }
    public ISelectable GetUnit(int index = 0) => Count > index ? selectedUnits[index] : null;
}
