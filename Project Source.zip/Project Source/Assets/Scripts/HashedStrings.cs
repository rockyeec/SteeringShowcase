using UnityEngine;

public static class HashedStrings
{
    public static readonly int locomotion = Animator.StringToHash("Locomotion");
    public static readonly int idle = Animator.StringToHash("Idle");
    public static readonly int moveZ = Animator.StringToHash("moveZ");
    public static readonly int brake = Animator.StringToHash("Brake");
}
