using System.Collections.Generic;

public interface IState
{
    void OnEnter();
    void OnExit();
    void Tick(in float deltaTime);
}

public class StateMachine
{
    IState currentState;
    List<Transition> currentTransitions;
    readonly Dictionary<System.Type, List<Transition>> transitions = new Dictionary<System.Type, List<Transition>>();
    readonly List<Transition> anyTransitions = new List<Transition>();
    static readonly List<Transition> emptyTransitions = new List<Transition>(0);

    public void Tick(in float deltaTime)
    {
        var transition = GetTransition();
        if (transition != null)
            SetState(transition.To);

        currentState?.Tick(deltaTime);
    }
    public void SetState(IState state)
    {
        if (state == currentState)
            return;

        currentState?.OnExit();
        currentState = state;

        transitions.TryGetValue(currentState.GetType(), out currentTransitions);
        if (currentTransitions == null)
        {
            currentTransitions = emptyTransitions;
        }

        currentState.OnEnter();
    }
    public void AddTransition(IState from, IState to, System.Func<bool> predicate)
    {
        if (!transitions.TryGetValue(from.GetType(), out var trans))
        {
            trans = new List<Transition>();
            transitions[from.GetType()] = trans;
        }
        trans.Add(new Transition(to, predicate));
    }
    public void AddAnyTransition(IState state, System.Func<bool> predicate)
    {
        anyTransitions.Add(new Transition(state, predicate));
    }
    class Transition
    {
        public IState To { get; }
        public System.Func<bool> Condition { get; }
        public Transition(IState to, System.Func<bool> condition)
        {
            To = to;
            Condition = condition;
        }
    }
    Transition GetTransition()
    {
        foreach (var item in anyTransitions)
        {
            if (item.Condition())
                return item;
        }

        foreach (var item in currentTransitions)
        {
            if (item.Condition())
                return item;
        }

        return null;
    }
}
