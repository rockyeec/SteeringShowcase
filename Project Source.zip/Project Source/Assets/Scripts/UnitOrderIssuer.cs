using UnityEngine;
using rockUtil;
using System.Collections.Generic;

public class UnitOrderIssuer : MonoBehaviour
{
    [Header("Formation Settings")]
    [SerializeField] float unitSpacing = 2.2f;

    [Header("Components")]
    [SerializeField] SelectedUnits selectedUnits = null;
    [SerializeField] TopDownCameraController topDownCameraController = null;

    List<OrderData> UnitDatas { get; } = new List<OrderData>();
    class OrderData
    {
        public Vector2 Formation { get; set; }
        public Vector3 IntendedTarget { get; set; }
    }
    Vector2 Origin { get; set; }
    Vector2 End { get; set; }

    float mouseHoldTime;
    readonly float mouseHoldDuration = 0.15f;

    public bool IsMouseHeldLongEnough => Time.time > mouseHoldTime;

    public Vector2 GetIntendedTarget(int index)
        => MouseGetter.WorldToScreenPoint( UnitDatas[index].IntendedTarget );

    private void Reset()
    {
        topDownCameraController = FindObjectOfType<TopDownCameraController>();
        selectedUnits = FindObjectOfType<SelectedUnits>();
    }

    private void Awake()
    {
        if (topDownCameraController == null)
            topDownCameraController = FindObjectOfType<TopDownCameraController>();
        if (selectedUnits == null)
            selectedUnits = FindObjectOfType<SelectedUnits>();

        RectangleSelector.OnSelect += UpdateFormation;
        ClickSelector.OnSelect += UpdateFormation;
    }


    private void OnDestroy()
    {
        RectangleSelector.OnSelect -= UpdateFormation; 
        ClickSelector.OnSelect -= UpdateFormation;
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(1))  Mouse1Down();
        if (Input.GetMouseButton(1))      Mouse1Drag();
        if (Input.GetMouseButtonUp(1))    Mouse1Up();
    }
    private void Mouse1Down()
    {
        if (topDownCameraController)
            topDownCameraController.enabled = false;
        Origin = Input.mousePosition;
        mouseHoldTime = Time.time + mouseHoldDuration;
    }
    private void Mouse1Up()
    {
        if (topDownCameraController)
            topDownCameraController.enabled = true;
        if (!IssuePursueOrder())
            IssueMoveOrder();
    }
    private void Mouse1Drag()
    { 
        if (!IsMouseHeldLongEnough)
            return;

        End = Input.mousePosition;
        int total = UnitDatas.Count;

        if (total == 0)
            return;

        if (total == 1)
        {
            Vector3? pMouse = MouseGetter.Point;
            if (pMouse != null)
                UnitDatas[0].IntendedTarget = pMouse.Value;
            return;
        }

        Vector3? originWorldPoint = MouseGetter.GetNullableGroundPoint(Origin);
        Vector3? endWorldPoint = MouseGetter.GetNullableGroundPoint(End);
        if (originWorldPoint != null && endWorldPoint != null)
        {
            Vector3 displacement = endWorldPoint.Value - originWorldPoint.Value;
            Vector3 right = displacement.normalized;
            Vector3 back = Vector3.Cross(Vector3.up, right).normalized;
            float distance = Vector3.Distance(originWorldPoint.Value, endWorldPoint.Value);
            distance = Mathf.Max(distance, 1e-5f);
            int columns = Mathf.CeilToInt(distance / unitSpacing);

            int i = 0;
            selectedUnits.ForEach(item =>
            {
                float z = (int)(i / columns) * unitSpacing;
                float x = (int)(i % columns) * unitSpacing;
                Vector3? pTarget = MouseGetter.GetNullableGroundPoint(originWorldPoint.Value + x * right + z * back, 69.0f);
                if (pTarget != null)
                {
                    UnitDatas[i].IntendedTarget = pTarget.Value;
                }
                ++i;
            });
        }
    }
        
    private void UpdateFormation()
    {
        int difference = selectedUnits.Count - UnitDatas.Count;
        if (difference > 0)
        {
            for (int i = 0; i < difference; i++)
            {
                UnitDatas.Add(new OrderData());
            }
        }        
        Vector2 total = Vector2.zero;
        {
            int i = 0;
            selectedUnits.ForEach(item =>
                {
                    Vector2 position2D = item.Target.AsVector2WithYZswap();
                    UnitDatas[i].Formation = position2D;
                    total += position2D;
                    ++i;
                });
        }
        Vector2 formationCenter = total / selectedUnits.Count;
        {
            for (int i = 0, length = UnitDatas.Count; i < length; i++)
            {
                UnitDatas[i].Formation -= formationCenter;
            }
        }
    }

    private void IssueMoveOrder()
    {
        if (selectedUnits.Count == 0)
            return;

        int i = 0;
        if (IsMouseHeldLongEnough)
        {
            selectedUnits.ForEach(item =>
            {
                item.Go(UnitDatas[i].IntendedTarget);
                ++i;
            });
            UpdateFormation();
        }
        else
        {
            selectedUnits.ForEach(item =>
            {
                Vector3? pTarget = MouseGetter.GetNullableGroundPoint((Vector2)Input.mousePosition);
                if (pTarget != null)
                {
                    pTarget = MouseGetter.GetNullableGroundPoint(pTarget.Value + UnitDatas[i].Formation.AsVector3WithYZswap(), 69.0f );

                    if (pTarget != null)
                        item.Go(pTarget.Value);
                }
                ++i;
            });
        }
    }

    private bool IssuePursueOrder()
    {
        if (!IsMouseHeldLongEnough)
        {
            GameObject victim = MouseGetter.SelectObject(selectedUnits.SelectableLayer);
            if (victim != null)
            {
                var vehicle = victim.GetComponent<IVehicle>();
                if (vehicle != null)
                {
                    selectedUnits.ForEach(item => item.Pursue(vehicle));
                    return true;
                }
            }
        }
        selectedUnits.ForEach(item => item.Pursue(null));
        return false;        
    }
}
