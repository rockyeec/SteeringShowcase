using UnityEngine;

public class SeekState : LocomotionState
{
    public SeekState(IVehicle vehicle, Animator animator)
        :
        base(vehicle, animator)
    { }
    
    public override void Tick(in float deltaTime)
    {
        Vector3 desiredVelocity = Vehicle.SpeedFactor * (Vehicle.Target - Vehicle.Position).normalized * Vehicle.MaxSpeed;
        VehicleUtility.UpdateFromDesiredVelocity(Vehicle, desiredVelocity, deltaTime);

        base.Tick(deltaTime);
    }
}