using UnityEngine;

public class PursuitState : LocomotionState
{
    Vector3 targetPositionLastFrame;

    public PursuitState(IVehicle vehicle, Animator animator)
        : 
        base(vehicle, animator) 
    { }

    public override void OnEnter()
    {
        base.OnEnter();
        targetPositionLastFrame = Vehicle.Target;
    }

    public override void Tick(in float deltaTime)
    {
        Vector3 targetOffset = Vehicle.Target - Vehicle.Position;
        Vector3 targetDirection = targetOffset.normalized;

        Vector3 targetFrameOffset = Vehicle.Target - targetPositionLastFrame;
        Vector3 approximatedTargetVelocity = targetFrameOffset / Mathf.Max(1e-5f, deltaTime);
        Vector3 targetMoveDirection = approximatedTargetVelocity.normalized;

        float dot = Vector3.Dot(targetDirection, targetMoveDirection);
        Vector3 predictedTargetPosition = Vehicle.Target;
        if (dot >= 0.0f)
            predictedTargetPosition += approximatedTargetVelocity * CalculateEstimationTime(targetOffset);

        Vector3 predictedTargetOffset = (predictedTargetPosition - Vehicle.Position);
        Vector3 predictedTargetDirection = predictedTargetOffset.normalized;

        Vector3 desiredVelocity = Vehicle.SpeedFactor * predictedTargetDirection * Vehicle.MaxSpeed;

        // Cache for next frame
        targetPositionLastFrame = Vehicle.Target;

        VehicleUtility.UpdateFromDesiredVelocity(Vehicle, desiredVelocity, deltaTime);

        base.Tick(deltaTime);
    }
    private float CalculateEstimationTime(Vector3 targetOffset)
        => targetOffset.sqrMagnitude / (Vehicle.MaxSpeed * Vehicle.MaxSpeed);
}