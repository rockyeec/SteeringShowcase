using UnityEngine;
public interface ICanArrive
{
    float ArriveRadius { get; }
}
public class ArriveState : LocomotionState
{
    ICanArrive ICanArrive { get; }

    public ArriveState(IVehicle vehicle, Animator animator, ICanArrive iCanArrive)
        : 
        base(vehicle, animator)
    {
        ICanArrive = iCanArrive;
    }

    public override void Tick(in float deltaTime)
    {
        Vector3 targetOffset = Vehicle.Target - Vehicle.Position;
        float distance = Mathf.Max(1e-3f, targetOffset.magnitude);
        float rampedSpeed = Vehicle.MaxSpeed * (distance / ICanArrive.ArriveRadius);
        float clippedSpeed = Mathf.Min(rampedSpeed, Vehicle.MaxSpeed);
        Vector3 desiredVelocity = Vehicle.SpeedFactor * (clippedSpeed / distance) * targetOffset;

        VehicleUtility.UpdateFromDesiredVelocity(Vehicle, desiredVelocity, deltaTime);

        Animator.SetFloat(HashedStrings.moveZ, Vehicle.Velocity.magnitude / Mathf.Max(1e-3f, Vehicle.MaxSpeed));

        base.Tick(deltaTime);
    }
}
