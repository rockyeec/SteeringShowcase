using UnityEngine;
using System;
using Random = UnityEngine.Random;
public interface ICanWander
{
    float WanderDecisionInterval { get; }
    float WanderRadius { get; }
    float WanderDistanceAhead { get; }
}

public class WanderState : LocomotionState
{
    ICanWander ICanWander { get; }
    Action<Vector3> OnUpdatetarget { get; }

    float nextTime = 0.0f;
    Vector3 currentTargetLocation;

    public WanderState(IVehicle vehicle, Animator animator, ICanWander iCanWander, Action<Vector3> onUpdateTarget)
        :
        base(vehicle, animator)
    {
        ICanWander = iCanWander;
        OnUpdatetarget = onUpdateTarget;
    }

    public override void Tick(in float deltaTime)
    {
        if (Time.time >= nextTime)
        {
            nextTime = Time.time + ICanWander.WanderDecisionInterval;

            Vector3 forwardPosition = Vehicle.Position + (Animator.transform.forward * ICanWander.WanderDistanceAhead);
            Vector2 randomInsideCircle = Random.insideUnitCircle.normalized * ICanWander.WanderRadius;
            Vector3 targetPosition = forwardPosition + randomInsideCircle.AsVector3WithYZswap();
            targetPosition = VehicleUtility.GetGroundPoint(targetPosition, 69.0f);

            //Debug.DrawLine(forwardPosition, targetPosition, Color.red, ICanWander.WanderDecisionInterval);
            //Debug.DrawLine(Vehicle.Position, forwardPosition, Color.green, ICanWander.WanderDecisionInterval);
            //Debug.DrawLine(Vehicle.Position, targetPosition, Color.blue, ICanWander.WanderDecisionInterval);

            currentTargetLocation = targetPosition;
        }
        OnUpdatetarget(currentTargetLocation);

        Vector3 targetOffset = currentTargetLocation - Vehicle.Position;
        Vector3 targetDirection = targetOffset.normalized;
        Vector3 desiredVelocity =  Vehicle.MaxSpeed * Vehicle.SpeedFactor * targetDirection;

        VehicleUtility.UpdateFromDesiredVelocity(Vehicle, desiredVelocity, in deltaTime);

        base.Tick(deltaTime);
    }
}