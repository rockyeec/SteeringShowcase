using UnityEngine;

public class FlockState : LocomotionState
{
    public FlockState(IVehicle vehicle, Animator animator)
        :
        base(vehicle, animator)
    { }

    public override void OnEnter()
    {
        base.OnEnter();
        FlockDirector.Add(Vehicle);
    }
    public override void OnExit()
    {
        base.OnExit();
        FlockDirector.Remove(Vehicle);
    }
}

