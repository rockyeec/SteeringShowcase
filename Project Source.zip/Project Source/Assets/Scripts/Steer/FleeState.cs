using UnityEngine;

public class FleeState : LocomotionState
{
    public FleeState(IVehicle vehicle, Animator animator)
        :
        base(vehicle, animator)
    { }

    public override void Tick(in float deltaTime)
    {
        Vector3 desiredVelocity = (Vehicle.Position - Vehicle.Target).normalized * Vehicle.MaxSpeed;
        VehicleUtility.UpdateFromDesiredVelocity(Vehicle, desiredVelocity, deltaTime);

        base.Tick(deltaTime);
    }
}