using UnityEngine;
using System.Collections.Generic;
using Random = UnityEngine.Random;

public static class Extensions
{
    public static Vector3 With(this Vector3 v, float? x = null, float? y = null, float? z = null)
        => new Vector3(x ?? v.x, y ?? v.y, z ?? v.z);

    public static Vector3 AsVector3WithYZswap(this Vector2 v2)
        => new Vector3(v2.x, 0.0f, v2.y);
    public static Vector2 AsVector2WithYZswap(this Vector3 v3)
        => new Vector2(v3.x, v3.z);

    public static bool IsLongerThan(this Vector3 v, float length)
        => v.sqrMagnitude > length * length;
    public static bool IsShorterThan(this Vector3 v, float length)
        => v.sqrMagnitude < length * length;
    public static bool IsLongerThan(this Vector2 v, float length)
        => v.sqrMagnitude > length * length;
    public static bool IsShorterThan(this Vector2 v, float length)
        => v.sqrMagnitude < length * length;

    public static T GetRandom<T>(this List<T> thisList)
        => thisList[Random.Range(0, thisList.Count - 1)];    
    public static T GetRandom<T>(this T[] thisList)
        => thisList[Random.Range(0, thisList.Length - 1)];

}
